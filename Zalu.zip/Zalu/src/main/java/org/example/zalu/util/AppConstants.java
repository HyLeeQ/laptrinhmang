package org.example.zalu.util;

public class AppConstants {
    public static final double LOGIN_WIDTH = 1200;
    public static final double LOGIN_HEIGHT = 777;

    public static final double REGISTER_WIDTH = 1200;
    public static final double REGISTER_HEIGHT = 777;

    public static final double MAIN_WIDTH = 1200;
    public static final double MAIN_HEIGHT = 750;
    
    public static final double FRIEND_REQUEST_WIDTH = 1200;
    public static final double FRIEND_REQUEST_HEIGHT = 750;
}